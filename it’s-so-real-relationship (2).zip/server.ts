import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const db = new Database("ethereal.db");

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS partners (
    id TEXT PRIMARY KEY,
    name TEXT,
    gender TEXT,
    personality TEXT,
    appearance TEXT,
    role TEXT,
    imageUrl TEXT,
    gallery TEXT,
    voiceName TEXT,
    artStyle TEXT,
    externalPlatforms TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    partnerId TEXT,
    role TEXT,
    content TEXT,
    imageUrl TEXT,
    videoUrl TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(partnerId) REFERENCES partners(id)
  );

  CREATE TABLE IF NOT EXISTS memories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    partnerId TEXT,
    content TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(partnerId) REFERENCES partners(id)
  );
`);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ limit: '50mb', extended: true }));

  // API Routes
  app.get("/api/partners", (req, res) => {
    const partners = db.prepare("SELECT * FROM partners ORDER BY createdAt DESC").all();
    res.json(partners.map(p => ({
      ...p,
      gallery: p.gallery ? JSON.parse(p.gallery) : [],
      externalPlatforms: p.externalPlatforms ? JSON.parse(p.externalPlatforms) : []
    })));
  });

  app.post("/api/partners", (req, res) => {
    const { id, name, gender, personality, appearance, role, imageUrl, gallery, voiceName, artStyle, externalPlatforms } = req.body;
    const stmt = db.prepare(`
      INSERT INTO partners (id, name, gender, personality, appearance, role, imageUrl, gallery, voiceName, artStyle, externalPlatforms)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    stmt.run(
      id, 
      name, 
      gender, 
      personality, 
      appearance, 
      role, 
      imageUrl, 
      gallery ? JSON.stringify(gallery) : null, 
      voiceName || 'Kore',
      artStyle || 'Photorealistic',
      externalPlatforms ? JSON.stringify(externalPlatforms) : null
    );
    res.json({ success: true });
  });

  app.put("/api/partners/:id/gallery", (req, res) => {
    const { gallery } = req.body;
    const stmt = db.prepare("UPDATE partners SET gallery = ? WHERE id = ?");
    stmt.run(JSON.stringify(gallery), req.params.id);
    res.json({ success: true });
  });

  app.put("/api/partners/:id/voice", (req, res) => {
    const { voiceName } = req.body;
    const stmt = db.prepare("UPDATE partners SET voiceName = ? WHERE id = ?");
    stmt.run(voiceName, req.params.id);
    res.json({ success: true });
  });

  app.delete("/api/partners/:id", (req, res) => {
    db.prepare("DELETE FROM messages WHERE partnerId = ?").run(req.params.id);
    db.prepare("DELETE FROM partners WHERE id = ?").run(req.params.id);
    res.json({ success: true });
  });

  app.get("/api/messages/:partnerId", (req, res) => {
    const messages = db.prepare("SELECT * FROM messages WHERE partnerId = ? ORDER BY timestamp ASC")
      .all(req.params.partnerId);
    res.json(messages);
  });

  app.get("/api/memories/:partnerId", (req, res) => {
    const memories = db.prepare("SELECT * FROM memories WHERE partnerId = ? ORDER BY timestamp DESC LIMIT 20")
      .all(req.params.partnerId);
    res.json(memories);
  });

  app.post("/api/memories", (req, res) => {
    const { partnerId, content } = req.body;
    const stmt = db.prepare("INSERT INTO memories (partnerId, content) VALUES (?, ?)");
    stmt.run(partnerId, content);
    res.json({ success: true });
  });

  app.post("/api/messages", (req, res) => {
    const { partnerId, role, content, imageUrl, videoUrl } = req.body;
    const stmt = db.prepare("INSERT INTO messages (partnerId, role, content, imageUrl, videoUrl) VALUES (?, ?, ?, ?, ?)");
    stmt.run(partnerId, role, content, imageUrl || null, videoUrl || null);
    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
