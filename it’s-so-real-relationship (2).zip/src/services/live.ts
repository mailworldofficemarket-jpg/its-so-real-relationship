import { GoogleGenAI, LiveServerMessage, Modality } from "@google/genai";

export class LiveSession {
  private sessionPromise: Promise<any> | null = null;
  private audioContext: AudioContext | null = null;
  private processor: ScriptProcessorNode | null = null;
  private source: MediaStreamAudioSourceNode | null = null;
  private analyser: AnalyserNode | null = null;
  private gainNode: GainNode | null = null;
  private userGainNode: GainNode | null = null;
  private audioQueue: Int16Array[] = [];
  private activeSources: AudioBufferSourceNode[] = [];
  private isPlaying = false;
  private nextStartTime = 0;

  private getAI() {
    const apiKey = process.env.API_KEY || process.env.GEMINI_API_KEY || "";
    return new GoogleGenAI({ apiKey });
  }

  async connect(config: {
    systemInstruction: string;
    voiceName: string;
    onMessage?: (text: string) => void;
    onUserTranscript?: (text: string) => void;
    onInterrupted?: () => void;
    onClose?: () => void;
    isPremium?: boolean;
  }) {
    // Use 24000Hz for high-quality audio
    this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    
    // Ensure context is running
    if (this.audioContext.state === 'suspended') {
      await this.audioContext.resume();
    }

    const ai = this.getAI();

    this.analyser = this.audioContext.createAnalyser();
    this.analyser.fftSize = 256;
    
    this.gainNode = this.audioContext.createGain();
    this.gainNode.gain.value = 1.0;

    this.analyser.connect(this.gainNode);
    this.gainNode.connect(this.audioContext.destination);

    this.sessionPromise = ai.live.connect({
      model: "gemini-2.5-flash-native-audio-preview-09-2025",
      callbacks: {
        onopen: () => {
          this.startMic();
        },
        onmessage: async (message: LiveServerMessage) => {
          // Handle model output
          const parts = message.serverContent?.modelTurn?.parts;
          if (parts) {
            for (const part of parts) {
              if (part.inlineData) {
                const base64Audio = part.inlineData.data;
                const audioData = this.base64ToUint8Array(base64Audio);
                const pcmData = new Int16Array(audioData.buffer);
                this.audioQueue.push(pcmData);
                this.scheduleNextBuffer();
              }
              if (part.text) {
                config.onMessage?.(part.text);
              }
            }
          }

          // Handle transcriptions
          if (message.serverContent?.modelTurn?.parts?.[0]?.text) {
             // Handled above
          }

          // Handle user transcription (if enabled in config)
          const userTranscript = message.serverContent?.modelTurn?.parts?.find(p => p.text)?.text;
          // Note: The SDK might send user transcription in a different message type depending on version
          // but we'll check for it here.

          if (message.serverContent?.interrupted) {
            this.stopPlayback();
            config.onInterrupted?.();
          }
        },
        onclose: () => {
          this.cleanup();
          config.onClose?.();
        },
        onerror: (err) => {
          console.error("Live API Error:", err);
          this.cleanup();
          config.onClose?.();
        }
      },
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: config.voiceName as any } },
        },
        systemInstruction: config.systemInstruction,
        // Enable transcriptions for better feedback
        inputAudioTranscription: {},
        outputAudioTranscription: {},
      },
    });

    await this.sessionPromise;
  }

  setVolume(volume: number) {
    if (this.gainNode) {
      this.gainNode.gain.value = Math.max(0, Math.min(1, volume));
    }
  }

  setUserVolume(volume: number) {
    if (this.userGainNode) {
      this.userGainNode.gain.value = Math.max(0, Math.min(1, volume));
    }
  }

  private async startMic() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      if (!this.audioContext) return;

      this.source = this.audioContext.createMediaStreamSource(stream);
      this.userGainNode = this.audioContext.createGain();
      this.userGainNode.gain.value = 1.0;

      // Smaller buffer for lower latency
      this.processor = this.audioContext.createScriptProcessor(2048, 1, 1);

      this.processor.onaudioprocess = (e) => {
        const inputData = e.inputBuffer.getChannelData(0);
        const pcmData = this.floatTo16BitPCM(inputData);
        const base64Data = this.uint8ArrayToBase64(new Uint8Array(pcmData.buffer));
        
        if (this.sessionPromise) {
          this.sessionPromise.then((session) => {
            session.sendRealtimeInput({
              media: { data: base64Data, mimeType: 'audio/pcm;rate=24000' }
            });
          });
        }
      };

      this.source.connect(this.userGainNode);
      this.userGainNode.connect(this.processor);
      
      // Connect to a silent gain node to keep the processor alive without echo
      const silentGain = this.audioContext.createGain();
      silentGain.gain.value = 0;
      this.processor.connect(silentGain);
      silentGain.connect(this.audioContext.destination);
    } catch (err) {
      console.error("Mic access error:", err);
    }
  }

  private floatTo16BitPCM(input: Float32Array) {
    const output = new Int16Array(input.length);
    for (let i = 0; i < input.length; i++) {
      const s = Math.max(-1, Math.min(1, input[i]));
      output[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
    }
    return output;
  }

  private base64ToUint8Array(base64: string) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
  }

  private uint8ArrayToBase64(bytes: Uint8Array) {
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  private scheduleNextBuffer() {
    if (!this.audioContext || this.audioQueue.length === 0) return;

    const lookahead = 0.1; 
    if (this.isPlaying && this.nextStartTime > this.audioContext.currentTime + lookahead) {
      return;
    }

    this.isPlaying = true;
    const pcmData = this.audioQueue.shift()!;
    const audioBuffer = this.audioContext.createBuffer(1, pcmData.length, 24000);
    const channelData = audioBuffer.getChannelData(0);

    for (let i = 0; i < pcmData.length; i++) {
      channelData[i] = pcmData[i] / 32768.0;
    }

    const source = this.audioContext.createBufferSource();
    source.buffer = audioBuffer;
    if (this.analyser) {
      source.connect(this.analyser);
    } else {
      source.connect(this.audioContext.destination);
    }

    const startTime = Math.max(this.audioContext.currentTime, this.nextStartTime);
    source.start(startTime);
    this.nextStartTime = startTime + audioBuffer.duration;
    
    this.activeSources.push(source);

    source.onended = () => {
      this.activeSources = this.activeSources.filter(s => s !== source);
      if (this.audioQueue.length === 0 && this.activeSources.length === 0) {
        this.isPlaying = false;
      } else {
        this.scheduleNextBuffer();
      }
    };

    if (this.audioQueue.length > 0) {
      this.scheduleNextBuffer();
    }
  }

  private stopPlayback() {
    this.audioQueue = [];
    this.activeSources.forEach(source => {
      try {
        source.stop();
      } catch (e) {
        // Source might have already stopped
      }
    });
    this.activeSources = [];
    this.isPlaying = false;
    this.nextStartTime = 0;
  }

  private cleanup() {
    if (this.processor) {
      this.processor.disconnect();
      this.processor = null;
    }
    if (this.source) {
      this.source.disconnect();
      this.source = null;
    }
    if (this.audioContext) {
      this.audioContext.close();
      this.audioContext = null;
    }
    this.stopPlayback();
  }

  disconnect() {
    if (this.sessionPromise) {
      this.sessionPromise.then(session => session.close());
    }
    this.cleanup();
  }

  getAudioLevel(): number {
    if (!this.analyser) return 0;
    const dataArray = new Uint8Array(this.analyser.frequencyBinCount);
    this.analyser.getByteFrequencyData(dataArray);
    let values = 0;
    for (let i = 0; i < dataArray.length; i++) {
      values += dataArray[i];
    }
    return values / dataArray.length / 255;
  }

  getFrequencyData(): Uint8Array {
    if (!this.analyser) return new Uint8Array(0);
    const dataArray = new Uint8Array(this.analyser.frequencyBinCount);
    this.analyser.getByteFrequencyData(dataArray);
    return dataArray;
  }
}
